# MEDCNN: Multiresolution Encoder-Decoder Convolutional Neural Network 

  - This MEDCNN version is without attentions in the decoder
  - Full paper with attentions: https://doi.org/10.1109/ICASSP49660.2025.10890832